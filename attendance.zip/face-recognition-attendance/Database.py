from calendar import c
import os
import csv
from datetime import datetime, timedelta

def create_or_check_attendance_file():
    # Define the folder name
    folder_name = "attendance"
    
    # Check if the 'attendance' folder exists, if not create it
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
        print(f"Folder '{folder_name}' created.")

    # Get the current date
    current_date = datetime.now().strftime("%d-%m")
    file_name = f"{current_date}.csv"
    
    # Check if the file exists in the 'attendance' folder
    file_path = os.path.join(folder_name, file_name)
    if os.path.exists(file_path):
        print(f"The file '{file_name}' already exists in the '{folder_name}' folder.")
    else:
        # Create the CSV file with headers
        with open(file_path, 'w', newline='') as csvfile:
            fieldnames = ['Student ID', 'Name', 'Check-in Time', 'Check-out Time']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
        print(f"New file '{file_name}' created in the '{folder_name}' folder.")


def mark_attendance(file_path, name, student_id):
    # Load the CSV file content into a list of dictionaries
    with open(file_path, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        rows = list(reader)

    checked_out = False
    already_checked_in = False
    current_time = datetime.now()
    current_time_str = current_time.strftime("%H:%M:%S")

    # Iterate over the rows
    for row in rows:
        if row['Name'] == name:
            if row['Check-out Time'] == '':
                check_in_time = datetime.strptime(row['Check-in Time'], "%H:%M:%S")
                check_in_time = check_in_time.replace(year=datetime.now().year, month=datetime.now().month, day=datetime.now().day)
                if current_time - check_in_time >= timedelta(hours=1):
                    row['Check-out Time'] = current_time_str
                    checked_out = True
                already_checked_in = True

    # Write the updated rows back to the CSV file
    if checked_out:
        with open(file_path, 'w', newline='') as csvfile:
            fieldnames = rows[0].keys() if rows else ['Student ID', 'Name', 'Check-in Time', 'Check-out Time']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    elif not already_checked_in:
        # Append a new row
        with open(file_path, 'a', newline='') as csvfile:
            fieldnames = rows[0].keys() if rows else ['Student ID', 'Name', 'Check-in Time', 'Check-out Time']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writerow({'Student ID': student_id, 'Name': name, 'Check-in Time': current_time_str, 'Check-out Time': ''})

mark_attendance('attendance/19-04.csv', 'jack', '12346')